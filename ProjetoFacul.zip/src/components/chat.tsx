import { useEffect, useRef, useState } from 'react';
import { Box, Textarea, Button, Text } from '@mantine/core';
import './chat.css';

interface Message {
  sender: 'user' | 'support';
  text: string;
  time: string;
}

function Chat() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const [shouldRender, setShouldRender] = useState(false);

  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, typing]);

  useEffect(() => {
    if (isOpen) {
      setShouldRender(true);
      simulateSupportMessage();
    } else {
      setTimeout(() => setShouldRender(false), 500);
    }
  }, [isOpen]);

  function toggleChat() {
    setIsOpen((prev) => !prev);
  }

  function getCurrentTime(): string {
    const now = new Date();
    const h = now.getHours().toString().padStart(2, '0');
    const m = now.getMinutes().toString().padStart(2, '0');
    return `${h}:${m}`;
  }

  function sendMessage() {
    if (input.trim() === '') return;

    setMessages((prev) => [...prev, { sender: 'user', text: input, time: getCurrentTime() }]);
    setInput('');

    setTimeout(() => {
      setTyping(true);
      setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          { sender: 'support', text: 'Olá! Em que posso ajudar?', time: getCurrentTime() },
        ]);
        setTyping(false);
      }, 1200);
    }, 500);
  }

  function simulateSupportMessage() {
    if (messages.length > 0) return;

    setTyping(true);
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        { sender: 'support', text: 'Olá, me chamo Ghost, sou suporte do book.ia. Em que posso te ajudar?', time: getCurrentTime() },
      ]);
      setTyping(false);
    }, 1500);
  }

  return (
    <>
      {/* Botão flutuante */}
      <Button onClick={toggleChat} style={{ position: 'fixed', bottom: 24, right: 24, borderRadius: '50%', width: 56, height: 56, padding: 0, backgroundColor: '#2f2f2f', color: '#000', zIndex: 1500, boxShadow: '0 0px 15px rgba(128, 128, 128, 0.6)', display: 'flex', justifyContent: 'center', alignItems: 'center', overflow: 'hidden' }} title={isOpen ? 'Fechar chat' : 'Abrir chat'} >
        <img src="/ghost.png" alt="Chat" style={{ width: '64%', height: '64%', objectFit: 'cover' }} />
      </Button>

      {shouldRender && ( 
        <Box className={`chat-panel ${isOpen ? 'show' : 'hide'}`} style={{ position: 'fixed', bottom: 90, right: 24, width: 340, height: 420, backgroundColor: '#1e1e1e', borderRadius: 16, boxShadow: '0 8px 24px rgba(0,0,0,0.6)', display: 'flex', flexDirection: 'column', zIndex: 1400, color: 'white', overflow: 'hidden', boxSizing: 'border-box', padding: 0 }}>
          {/* Header */}
          <Box style={{ padding: '14px 18px', backgroundColor: '#2f2f2f', borderBottom: '2px solid #00ffff', fontWeight: 600, fontSize: 18, userSelect: 'none', flexShrink: 0 }}>
            💬 Ghost
          </Box>

          {/* Conteúdo */}
          <Box className='scroll-box' style={{ flex: 1, minHeight: 0, overflowY: 'auto', padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
            {messages.length === 0 && !typing && (
              <Text color="dimmed" size="sm" mt={16}>Nenhuma mensagem ainda...</Text>
            )}

            {messages.map((msg, i) => {
              const isUser = msg.sender === 'user';
              return (
                <Box key={i} style={{ alignSelf: isUser ? 'flex-end' : 'flex-start', backgroundColor: '#646464', color: '#eee', borderRadius: 10, fontFamily: 'Montserrat', padding: '10px 12px', maxWidth: '80%', fontSize: 12, wordBreak: 'break-word', display: 'flex', flexDirection: 'column' }}>
                  <Box>{msg.text}</Box>
                  <Box style={{ marginTop: 0, fontSize: 9, color: '#bbb', display: 'flex', fontFamily: 'Montserrat', fontWeight: '600', justifyContent: 'space-between', fontStyle: 'italic', userSelect: 'none' }}>
                    {isUser ? <span>Você - {msg.time}</span> : <span>Ghost - {msg.time}</span>}
                  </Box>
                </Box>
              );
            })}

            {typing && (
              <Text size="sm" color="dimmed" style={{ fontStyle: 'italic' }}>
                Ghost está digitando...
              </Text>
            )}
            <div ref={bottomRef} />
          </Box>

          {/* Input */}
          <Box style={{ padding: 12, borderTop: '2px solid #00ffff', display: 'flex', backgroundColor: '#2a2a2a', alignItems: 'flex-end' }}>
            <Textarea value={input} onChange={(e) => setInput(e.currentTarget.value)} placeholder="Digite sua mensagem..." autosize minRows={1} maxRows={3} styles={{ input: { backgroundColor: '#333', color: '#fff', borderRadius: 10, border: '1px solid #555', padding: '8px 20px', fontSize: 14, height: '75%', width: '100%', fontFamily: 'inherit', resize: 'none', lineHeight: 1.4}}} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage();}}}/>
            <Button onClick={sendMessage} disabled={input.trim() === ''} style={{ flexShrink: 0,  backgroundColor: '#00ffff', color: '#000', borderRadius: 10, margin: '0px 0px 0px 50px', padding: '10px 18px', transition: 'background 0.3s', height: 'auto', alignSelf: 'stretch' }} onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#00e0e0')} onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = '#00ffff')}>
              Enviar
            </Button>
          </Box>
        </Box>
      )}
    </>
  );
}

export default Chat;
