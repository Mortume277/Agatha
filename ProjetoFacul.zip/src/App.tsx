import {
  Text,
  Stack,
  Box,
  Image,
  Title,
  Card,
  Input,
} from '@mantine/core';
import { IconStarFilled } from '@tabler/icons-react';

const services = ['Marketing', 'Comercial', 'Divulgação', 'Automatização'];
const professionals = ['Programadores', 'Designers', 'Contadores', 'Advogados'];

import './App.css'

import Chat from './components/chat.tsx';
import { useState } from 'react';

const cards = [
  { name: 'ChatGPT', rating: 5, description: 'ChatGPT é uma AI versatil e pode ser usado em uma variedade de aplicativos, como serviços de cliente, agentes virtuais e chatbots. ' },
  { name: 'Freepik AI Image Generator', rating: 3, description: 'O Freepik AI Image Generator oferece uma ampla variedade de estilos predefinidos que podem ser aplicados a qualquer texto, permitindo diversas expressões artísticas. Esses estilos são organizados em categorias como Estilo, Cor, Enquadramento e Iluminação, e podem ser combinados para obter resultados excepcionais a partir de um único texto.' },
  { name: 'Gemini', rating: 4, description: 'O Gemini é um modelo de Inteligência Artificial de ponta desenvolvido pelo Google. Ele representa o modelo de IA geral mais avançado do Google até o momento e foi desenvolvido com recursos multimodais.' },
  { name: 'Perplexity', rating: 3, description: 'O Perplexity é um mecanismo de respostas baseado em IA, projetado para fornecer respostas em tempo real, precisas e confiáveis a uma variedade de perguntas. Seu objetivo é servir como um hub central de conhecimento e informações, disponível sem custo para seus usuários.' },
  { name: 'NotebookLM', rating: 4, description: 'O NotebookLM é uma ferramenta avançada de anotações que utiliza inteligência artificial para fornecer um assistente de pesquisa personalizado. O upload de documentos relevantes transforma o NotebookLM em um especialista nas informações que são importantes para você e pode ajudar a transformar suas anotações compiladas em uma variedade de recursos, como esboços, publicações em blogs, planos de negócios e muito mais.'},
  { name: 'Thea', rating: 2, description: 'Thea é uma ferramenta de estudo com tecnologia de IA projetada para facilitar o aprendizado mais eficaz dos alunos. Em vez de apenas ajudar na memorização, a Thea é voltada para ajudar os usuários a realmente dominar o material em questão. Essa ferramenta oferece uma variedade de perguntas envolventes e foi otimizada para manter a atenção do usuário, ajudando assim na retenção de informações.'},
  { name: 'Suno', rating: 4, description: 'A Suno é uma plataforma de geração de música com IA que permite aos usuários criar músicas completas, incluindo vocais, letras e instrumentais, a partir de instruções de texto. Ela permite a personalização de letras, estilos musicais e tons vocais, e pode até mesmo imitar o estilo de faixas existentes. O Suno foi projetado para ser fácil de usar, tornando a criação de músicas acessível tanto para iniciantes quanto para usuários experientes.'},
  { name: 'DeepSeek', rating: 3, description: 'O DeepSeek é uma ferramenta de IA capaz de raciocínio superalimentado, projetada para estratégias de longo prazo para resolver problemas complexos. Esse modelo de código aberto foi especialmente projetado para funcionar de forma eficaz em vários domínios, como aritmética, matemática, codificação e raciocínio.'},
  { name: 'Leonardo AI', rating: 4, description: 'O Leonardo AI é um conjunto abrangente de ferramentas de inteligência artificial projetado para elevar vários projetos criativos por meio da geração de arte, imagens e vídeo.'},
  { name: 'Claude', rating: 5, description: 'O Claude da Anthropic é um assistente de IA que pode ser personalizado para executar uma ampla gama de tarefas com um toque humano. Como uma IA constitucional, o Claude foi projetado para ser confiável, interpretável e orientável, com treinamento de inofensividade para garantir que ele possa lidar com parceiros de conversação desagradáveis ou mal-intencionados com elegância.'},
  { name: 'EditApp', rating: 3, description: 'O EditApp AI é uma ferramenta versátil que permite aos usuários criar e modificar facilmente imagens em seus dispositivos móveis. O aplicativo oferece três modos principais: Criar, Ajustar e Fundo.'},
  { name: 'Kaiber', rating: 4, description: 'O Kaiber é uma ferramenta inovadora de IA projetada para a geração de vídeos. Com base na inteligência artificial, ela simplifica e agiliza o processo de criação de conteúdo de vídeo envolvente'}
];

export default function App() {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredCards = cards.filter(card =>
    card.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  return (
    <>
      <Box style={{ width: '100%', position: 'fixed', top: 0, left: 0, bottom: 0, backgroundColor: '#707070', zIndex: 1000 }}>

        {/* Header fixo */}
        <Box style={{ position: 'fixed', top: 0, left: 0, width: 260, height: 73, backgroundColor: '#2f2f2f', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 16px', zIndex: 1100, borderBottomRightRadius: 12, borderRight: '2px solid #666', borderBottom: '2px solid #666' }}>
          <Box style={{ display: 'flex', alignItems: 'center', transform: 'translateX(38px) translateY(-12px)' }}>
            <Image src="/logo.png" width={64} height={64} style={{ borderRadius: 12 }} />
              <Text fw={900} span style={{ transform: 'translateY(4px)', display: 'flex', alignItems: 'center', marginLeft: 4 }}>
              <span style={{ color: 'white', letterSpacing: 1, fontFamily: 'monospace', fontSize: 20, userSelect: 'none' }}>BOOK</span>
              <span style={{ color: '#00ffff', fontFamily: 'monospace', fontSize: 16, paddingTop: 2, userSelect: 'none' }}>.ia</span>
              </Text>
          </Box>
          <Box style={{ height: 1, width: 80, backgroundImage: 'linear-gradient(to right, white 0%, white 60%, cyan 80%, transparent 100%)', marginTop: -25, marginLeft: 50 + 57, borderRadius: 1, }}/>
        </Box>

        {/* Menu lateral */}
        <Box style={{ width: 260, position: 'fixed', top: 75, left: 0, bottom: 0, backgroundColor: '#2f2f2f', color: 'white', padding: 16, borderTop: '2px solid #666', borderRight: '2px solid #666', zIndex: 1000, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 24, marginTop: 5, borderTopRightRadius: 12 }}>

          <Box>
            <Text size="md" fw={600} mb={8} ta="center" style={{userSelect: 'none'}}>Serviços IA's</Text>
            <Box style={{ height: 1, width: '100%', backgroundImage: 'linear-gradient(to right, transparent, white, transparent)', marginBottom: 12 }} />
            <Stack gap="xs">
              {services.map((s) => (
                <Text key={s} size="sm" style={{ color: '#ccc', padding: '6px 12px', borderRadius: 6, cursor: 'pointer', transition: '0.2s', userSelect: 'none'}} onMouseEnter={(e) => { e.currentTarget.style.backgroundImage = 'linear-gradient(to right, #444, transparent)'; }} onMouseLeave={(e) => { e.currentTarget.style.backgroundImage = 'none'; }}>{s}</Text>
              ))}
            </Stack>
          </Box>

          <Box>
            <Text size="md" fw={600} mb={8} ta="center" style={{userSelect: 'none'}}>Profissionais</Text>
            <Box style={{ height: 1, width: '100%', backgroundImage: 'linear-gradient(to right, transparent, white, transparent)', marginBottom: 12 }} />
            <Stack gap="xs">
              {professionals.map((s) => (
                <Text key={s} size="sm" style={{ color: '#ccc', padding: '6px 12px', borderRadius: 6, cursor: 'pointer', transition: '0.2s', userSelect: 'none'}} onMouseEnter={(e) => { e.currentTarget.style.backgroundImage = 'linear-gradient(to right, #444, transparent)'; }} onMouseLeave={(e) => { e.currentTarget.style.backgroundImage = 'none'; }}>{s}</Text>
              ))}
            </Stack>
          </Box>
        </Box>

        <Box style={{ position: 'fixed', top: 0, left: 300, width: '83%', height: '100%', backgroundColor: '#2f2f2f', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-start', padding: '32px 32px', gap: 0, zIndex: 1100, borderBottomRightRadius: 12, borderRight: '2px solid #666', borderBottom: '2px solid #666', overflowY: 'auto'}}>

          <Box style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: 120 }}>
            <img src="/logo.png" alt="Exemplo" style={{ width: 240, height: 240, objectFit: 'cover', filter: 'grayscale(100%) brightness(0.5)', borderRadius: 8, marginTop: -70, userSelect: 'none' }}/>
            <Text style={{ color: '#ccc', marginTop: -10, textAlign: 'center', filter: 'brightness(0.5)', letterSpacing: 1, fontFamily: 'monospace', fontSize: 20, userSelect: 'none' }}>
              Book.ia
            </Text>
          </Box>

          <Box style={{ width: '60%', paddingTop: 24, marginBottom: 0 }}>
            <Input placeholder="Pesquisar IA's" radius="md" size="md" value={searchTerm} onChange={(e) => setSearchTerm(e.currentTarget.value)} styles={{ input: { backgroundColor: '#444', border: '1px solid #666', color: 'white', padding: '10px 14px', fontSize: 14, fontFamily: 'monospace', width: '100%' }}}/>
          </Box>

          <Title order={3} ta="center" style={{ color: 'white', fontFamily: 'serif', marginBottom: -23, fontWeight: '600', userSelect: 'none', fontSize: '25px' }}>
            Mais recomendados
          </Title>

          <Box style={{ paddingTop: 32, width: '85%', maxHeight: '64%' }}>
            <div style={{ height: '2px', background: 'linear-gradient(to right, transparent, white, transparent)', marginBottom: 26 }} />

            <Box className="scroll-box" style={{ width: '100%', height: '79%', overflowY: 'auto', paddingRight: 12 }}>
              <Stack gap="md">
                {filteredCards.map((v, i) => (
                  <Card key={i} withBorder radius="md" style={{ backgroundColor: '#2f2f2f', border: '2px solid #ccc', color: 'white', borderRadius: 7, marginBottom: 20 }}>
                    <Box style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 0 }}>
                      <Text fw={700} style={{ fontSize: 18, marginLeft: 10 }}>{v.name}</Text>
                      <Box style={{ display: 'flex', gap: 4, marginRight: 17 }}>
                        {Array.from({ length: 5 }).map((_, idx) => (
                          <IconStarFilled key={idx} size={16} color={idx < v.rating ? '#00ffff' : 'white'} />
                        ))}
                      </Box>
                    </Box>

                    <Box style={{ paddingTop: -90, width: '99%' }}>
                      <div style={{ height: '2px', background: 'white', marginBottom: 0, marginLeft: 10 }} />
                    </Box>

                    <Box style={{ paddingLeft: '16px' }}>
                      <Text fw={600} mb={4} style={{ userSelect: 'none' }}>Descrição:</Text>
                      <Text size="sm" c="dimmed">{v.description}</Text>
                    </Box>
                  </Card>
                ))}
              </Stack>
            </Box>
          </Box>
        </Box>
        {/* Botão de chat de suporte */}
        <Chat />
      </Box>
    </>
  );
}
